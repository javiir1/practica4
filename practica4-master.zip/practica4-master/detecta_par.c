#include <stdio.h>
int main()
	{
	int num1;
	printf ("dame un numero:\n");
	scanf ("%d",&num1);
	if (num1%2==0)
		printf("el numero es par\n");
	else
		printf("el numero es impar\n");	
	return 0;
	}
